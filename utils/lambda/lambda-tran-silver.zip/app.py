import requests
import json
import boto3
from datetime import datetime


def extract_finance():
    #DATE CONFIG
    folder_ref = datetime.now().strftime("%Y%m%d")
    file_ref = datetime.now().strftime("%Y%m%d%H%M%S")

    #BUCKET CONFIG
    s3 = boto3.client('s3', endpoint_url='http://s3.localhost.localstack.cloud:4566')
    target_bucket = 'data-bronze'
    target_key = folder_ref

    #FAZ A REQUISIÇÃO PARA CAPTAR OS DADOS
    response = requests.get('https://economia.awesomeapi.com.br/last/USD-BRL,EUR-BRL,BTC-BRL,ETH-BRL,CAD-BRL')

    if response.status_code == 200:
        data = response.json()
        json_data = json.dumps(data, indent=4, ensure_ascii=False)
        s3.put_object(Body=json_data, Bucket = target_bucket, Key=f'{folder_ref}/finance_{file_ref}.json' )

    else:
        raise ValueError(f"Aconteceu um erro inesperado na extração | {response.status_code}")


def lambda_handler(event, context):
    try:
        extract_finance()
        return {
            'statusCode': 200,
            'body': json.dumps("Dados salvos no bucket com sucesso!")
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Erro ao salvar os dados: {str(e)}")
        }