import requests
import json
import boto3
from datetime import datetime


def extract_finance():

    #BOTO3 CONFIG
    s3 = boto3.client('s3', endpoint_url='http://s3.localhost.localstack.cloud:4566')
    sns = boto3.client('sns', endpoint_url='http://host.docker.internal:4566')

    #CONF VARS
    folder_ref = datetime.now().strftime("%Y%m%d")
    file_ref = datetime.now().strftime("%Y%m%d%H%M%S")
    target_bucket = 'data-bronze'
    file_name = f'{folder_ref}/finance_{file_ref}.json'

    sns_topic_arn = 'arn:aws:sns:us-east-1:000000000000:sns-integration'
    sns_message = {
        'event': 'file_upload',
        'bucket': target_bucket,
        'folder_ref': folder_ref,
        'file_name':file_name
    }

    #FAZ A REQUISIÇÃO PARA CAPTAR OS DADOS
    response = requests.get('https://economia.awesomeapi.com.br/last/USD-BRL,EUR-BRL,BTC-BRL,ETH-BRL,CAD-BRL')

    if response.status_code == 200:
        data = response.json()
        json_data = json.dumps(data, indent=4, ensure_ascii=False)

        s3.put_object(Body=json_data, Bucket = target_bucket, Key=file_name)
        sns.publish(TopicArn = sns_topic_arn, Message = json.dumps(sns_message))


    else:
        raise ValueError(f"Aconteceu um erro inesperado na extração | {response.status_code}")


def lambda_handler(event, context):
    try:
        extract_finance()
        return {
            'statusCode': 200,
            'body': json.dumps("Dados salvos e mensagem enviada")
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Erro: {str(e)}")
        }